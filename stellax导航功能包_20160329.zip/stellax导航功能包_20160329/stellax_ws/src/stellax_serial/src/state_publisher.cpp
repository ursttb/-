#include <string>
#include <ros/ros.h>
#include <sensor_msgs/JointState.h>
#include <tf/transform_broadcaster.h>
#include <nav_msgs/Odometry.h>
#include <boost/asio.hpp>
#include <boost/bind.hpp>
#include <math.h>

using namespace std;
using namespace boost::asio;

// initial position
double x = 0.0;
double y = 0.0;
double th = 0;

// velocity
double vx = 0.0;
double vy = 0.0;
double vth = 0.0;

unsigned char buf[9];

union tran
{
    short int i;
    unsigned char c[2];
}v1,v2,v3;

int main(int argc, char** argv) {

    ros::init(argc, argv, "state_publisher");
    ros::NodeHandle n;
    ros::Publisher odom_pub = n.advertise<nav_msgs::Odometry>("odom", 10);

    ros::Time current_time;
    ros::Time last_time;
    current_time = ros::Time::now();
    last_time = ros::Time::now();
    tf::TransformBroadcaster broadcaster;
    ros::Rate loop_rate(20);

    const double degree = M_PI/180;

    // message declarations
    geometry_msgs::TransformStamped odom_trans;
    odom_trans.header.frame_id = "odom";
    odom_trans.child_frame_id = "base_link";

    io_service iosev;
    serial_port sp(iosev, "/dev/ttyUSB1");
    sp.set_option(serial_port::baud_rate(115200));
    sp.set_option(serial_port::flow_control());
    sp.set_option(serial_port::parity());
    sp.set_option(serial_port::stop_bits());
    sp.set_option(serial_port::character_size(7));

    while (ros::ok()) {
 
        read (sp,buffer(buf));
        if(buf[0] == 's' && buf[8] == 'e')
        {
            v1.c[0] = buf[2];
            v1.c[1] = buf[3];
            v2.c[0] = buf[4];
            v2.c[1] = buf[5];
            v3.c[0] = buf[6];
            v3.c[1] = buf[7];

            vx=(sqrt(3)/3)*(v1.i-v2.i)/1000;
            vy=(1/3.0)*(v1.i+v2.i)/1000-(2/3.0)*(v3.i)/1000;
            vth=(1/(3*139.085))*(v1.i+v2.i+v3.i);

            printf("v1:%d,v2:%d,v3:%d\n",v1.i,v2.i,v3.i);
            //printf("vx:%F,vy:%F,vth:%F\n",vx,vy,vth);

            //vx=-1/3*v1.i-1/3*v2.i+2/3*v3.i;
            //vy=sqrt(3)/3*v1.i-sqrt(3)/3*v2.i;
            //vth=(v1.i+v2.i+v3.i)/(3*139.085);

            current_time = ros::Time::now();

            double dt = (current_time - last_time).toSec();
            double delta_x = (vx * cos(th) - vy * sin(th)) * dt;
            double delta_y = (vx * sin(th) + vy * cos(th)) * dt;
            double delta_th = vth * dt;

            x += delta_x;
            y += delta_y;
            th += delta_th;

            geometry_msgs::Quaternion odom_quat;
            odom_quat = tf::createQuaternionMsgFromRollPitchYaw(0,0,th);

            // update transform
            odom_trans.header.stamp = current_time;
            odom_trans.transform.translation.x = x;
            odom_trans.transform.translation.y = y;
            odom_trans.transform.translation.z = 0.0;
            odom_trans.transform.rotation = tf::createQuaternionMsgFromYaw(th);

            //filling the odometry
            nav_msgs::Odometry odom;
            odom.header.stamp = current_time;
            odom.header.frame_id = "odom";
            odom.child_frame_id = "base_link";

            // position
            odom.pose.pose.position.x = x;
            odom.pose.pose.position.y = y;
            odom.pose.pose.position.z = 0.0;
            odom.pose.pose.orientation = odom_quat;

            //velocity
            odom.twist.twist.linear.x = vx;
            odom.twist.twist.linear.y = vy;
            odom.twist.twist.linear.z = 0.0;
            odom.twist.twist.angular.x = 0.0;
            odom.twist.twist.angular.y = 0.0;
            odom.twist.twist.angular.z = vth;

            last_time = current_time;

            // publishing the odometry and the new tf
            broadcaster.sendTransform(odom_trans);
            odom_pub.publish(odom);
         }
    }
    return 0;
}
