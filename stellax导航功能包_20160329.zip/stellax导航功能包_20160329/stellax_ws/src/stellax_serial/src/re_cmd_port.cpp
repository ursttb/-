#include <ros/ros.h>
#include <geometry_msgs/Twist.h>
#include <boost/asio.hpp>
#include <boost/bind.hpp>
#include <istream>
#include <math.h>

//定义传输数据长度
const int LEN=6;

//定义初始的三个变量，x速度、y速度及z角度
double linear_x,linear_y,angular_z;

//定义一个命名空间，用于后面的write函数
using namespace boost::asio;

//定义传输的io口
io_service io;
serial_port sp(io, "/dev/ttyUSB1");

//定义速度接收→发送程序
void commandVelocityReceived (const geometry_msgs::Twist& msgIn);

//定义一个传输数组
unsigned char transform[9];

//定义一个联合体（16位的short int，8位的unsigned char），用于数据转换
union tran
{
   short int i;
   unsigned char c[2];
}v1,v2,v3,len;

int main(int argc, char **argv)
{
   //初始化ros
   ros::init(argc, argv, "re_cmd_port");
   ros::NodeHandle nh;

   //数据长度
   len.i=LEN;

   //传输数据帧头帧尾及数据长度
   transform[0]='s';
   transform[1]=len.c[0];
   transform[8]='e';

   //串口设置（波特率115200,1个停止位，7个数据位） 
   sp.set_option(serial_port::baud_rate(115200));
   sp.set_option(serial_port::flow_control());
   sp.set_option(serial_port::parity());
   sp.set_option(serial_port::stop_bits(serial_port::stop_bits::one));
   sp.set_option(serial_port::character_size(7));

   //调用速度接收→发送程序
   ros::Subscriber sub = nh.subscribe("/cmd_vel",1000,&commandVelocityReceived) ;
   ros::spin () ;
   sp.close ();
   return 0;
}


void commandVelocityReceived (const geometry_msgs::Twist& msgIn)
{
   //速度由m/s转换到mm/s
   linear_x = msgIn.linear.x*1000;
   linear_y = msgIn.linear.y*1000;
   angular_z =msgIn.angular.z;
   
   //将整机速度转换为三个轮子的速度
   v3.i=-linear_y+angular_z*139.085;
   v1.i=1/2*linear_y+sqrt(3)/2*linear_x+angular_z*139.085;
   v2.i=1/2*linear_y-sqrt(3)/2*linear_x+angular_z*139.085;
  
   //将short int(16位)的三个轮子速度转换为两个8位的char类型，并赋予传输数组
   transform[2]=v1.c[0];
   transform[3]=v1.c[1];
   transform[4]=v2.c[0];
   transform[5]=v2.c[1];
   transform[6]=v3.c[0];
   transform[7]=v3.c[1];

   //在终端输出三个轮子的速度（char类型，16进制显示），用于检验速度是否正确转换
   printf("v1.c[0]:%X,v1.c[1]:%X,v2.c[0]:%X,v2.c[1]:%X,v3.c[0]:%X,v3.c[1]:%X,\n",v1.c[0],v1.c[1],v2.c[0],v2.c[1],v3.c[0],v3.c[1]);

   //把char类型的transform数组（9位）通过串口写
   write(sp, buffer(transform, 9));
}
